# 7장 Context API

## 코드 실행

1. 디렉터리 이동

```
cd react-native-context
```

2. 종속성 설치 및 실행

```
npm install
npm start
```
