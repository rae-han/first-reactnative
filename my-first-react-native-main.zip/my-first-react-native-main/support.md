# Simple Chat - RN

## Start Simple Chat

To start Simple Chat, you have to need an email address and password to signup in the App.  
If you want to register your profile photo, you can upload your photo that is stored on your phone. If not, your profile photo is set to default photo.
After signup, you can log in to your ID that is your email address and password.

## Change your profile

You can change your profile on the profile page after login.
But, you can not change your name and email address that entered when you signup.

## Create a channel

The channels page is showing you the list of channels.
And there is a "Create a Channel" button on the right of the top of the page.
You can go to create a channel page if you click the button.
And you have to enter the title of the channel.
If you need to explain the purpose or other things of the channel, you can enter a message on description space.

## Send a message

You are able to send a message and receive a message on a specific channel.  
We do not support sending a photo or other file yet.

## Question

If you need to ask something about our App, please send an email to the below address with detailed information.

email: alchemistk831@gmail.com

Thanks.
