# 3장 컴포넌트

## 코드 실행

1. 디렉터리 이동

```
cd RNPressable
# or
cd react-native-component
```

2. 종속성 설치 및 실행

```
npm install
npm start
```
