# 변경사항

리액트 네이티브의 큰 변화에 의해 소스 코드가 변경되면, 관련된 내용을 확인할 수 있습니다.

## 2021-04-25

- [5장 코드 수정](https://github.com/Alchemist85K/my-first-react-native/blob/Expo-41/chapter05/CHANGELOG.md)
- [9장 코드 수정](https://github.com/Alchemist85K/my-first-react-native/blob/Expo-41/chapter09/CHANGELOG.md)

## 2021-02-11

- [오타 수정](https://github.com/Alchemist85K/my-first-react-native/blob/main/chapter04/CHANGELOG.md#2021-02-11)

## 2020-08

- 소스 코드 추가
