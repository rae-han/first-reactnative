const prefix =
  'https://firebasestorage.googleapis.com/v0/b/react-native-simple-chat-558a0.appspot.com/o';

export const images = {
  logo: `${prefix}/logo.png?alt=media`,
  photo: `${prefix}/photo.png?alt=media`,
};
